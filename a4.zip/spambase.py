from knnclassifier import knnclassifier
from classifier import data_item, normalize_dataset
from random import shuffle

# I have provided this code to read the data from the file.
fp = open('spambase.data')
dataset = []
for line in fp:
    fields = line.split(',')
    data = [float(x) for x in fields[:-1]] # convert to float
    label = int(fields[-1]) # final item is the label
    dataset.append(data_item(label, data))

print("Read {} items.".format(len(dataset)))
# The number of features is just the length of a feature vector.
print("{} features per item.".format(len(dataset[0].data)))

# YOUR CODE GOES AFTER THIS LINE!
