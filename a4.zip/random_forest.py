from random import sample
from decision_tree import greedy_decision_tree
from bagging import bagging_trees, sample_with_replacement

class random_forest_tree(greedy_decision_tree):
    '''Trees in a random forest are no different from decision
    trees in general, except that they only consider a randomly-
    chosen subset of their features as each node is constructed.'''
    def __init__(self, mtry):
        super().__init__()
        self.mtry = mtry

    def feature_indices(self, m):
        '''Return a subsampled list of feature indices.'''
        if self.mtry < 0:
            self.mtry = int(m ** 0.5)
        return sample(range(m), self.mtry)

class random_forest(bagging_trees):
    def __init__(self, M = 21, mtry = -1):
        '''Initialize the empty forest.'''
        super().__init__(M)
        self.mtry = mtry

    def train(self, training_data):
        '''Train a forest using the random forest algorithm.'''
        for i in range(self.M):
            dt = random_forest_tree(self.mtry)
            dt.train(training_data)
            self.forest.append(dt)

if __name__ == "__main__":
    from datasets import read_parkinsons_dataset
    from classifier import evaluate
    from random import shuffle
    dataset = read_parkinsons_dataset()
    shuffle(dataset)
    pct = evaluate(dataset, random_forest, 4, M=49)
    print('Random Forest: {:.2%}'.format(pct))

